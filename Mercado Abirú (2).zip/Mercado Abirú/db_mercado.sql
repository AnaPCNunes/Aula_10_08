create database mercado;
use mercado;

create table Funcionario (
id int auto_increment,
nome varchar(60),
cargo varchar(30),
primary key (id));

create table Produto (
cod int auto_increment,
descricao varchar(100),
valor float,
quantidade int,  
primary key (cod));

create table Abastecer (
cod int auto_increment,
observacoes varchar (400),
primary key (cod));

create table Abastecer_Produto (
cod_abastecer int,
cod_produto int,
dataAb timestamp,
primary key (cod_abastecer, cod_produto),
foreign key (cod_abastecer) references Abastecer (cod),
foreign key (cod_produto) references Produto (cod));

create table Venda (
cod int auto_increment,
observacoes varchar (400),
primary key (cod));

create table Venda_Produto (
cod_venda int,
cod_produto int,
dataVd timestamp,
valor_total float,
primary key (cod_venda, cod_produto),
foreign key (cod_venda) references Venda (cod),
foreign key (cod_produto) references Produto (cod));

select * from Produto;
select * from Funcionario;
select * from Abastecer;
select * from Abastecer_Produto;
select * from Venda;
select * from Venda_Produto;

insert into Funcionario values 
('234', 'Noah', 'Gerente'),
('235', 'Laís', 'Gerente'),
('236', 'Tiago', 'Caixa'),
('237', 'Denise', 'Caixa'),
('238', 'Marcos', 'Caixa'),
('239', 'Adelaide', 'Caixa');
