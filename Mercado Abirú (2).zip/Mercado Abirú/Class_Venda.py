from Class_Cadastro import *
from Class_RegistroVenda import *
from datetime import datetime

class Venda:
    def __init__(self):
        self.conexao = mysql.connector.connect(host='localhost', user='root', password='q1w2e3', database='mercado')
        self.cursorzinho = self.conexao.cursor()
        self.gerenciar = Cadastro()
        self.carrodecompra = []
    
    def iniciar_venda(self, cod, observacoes):
        obj_venda = RegistroVenda(cod, observacoes)
        comando_sql = f'insert into Venda (observacoes) value ("{obj_venda.observacoes}")'
        self.cursorzinho.execute(comando_sql)
        self.conexao.commit()
        
    def selecionar(self, proc_produto, quant=1):    
        venda = f'select valor from Produto where cod = {proc_produto}'
        self.cursorzinho.execute(venda)
        lista = self.cursorzinho.fetchall()
        produtos_c = (lista[0],[0]) * quant
        self.carrodecompra.append(produtos_c)
        total_compra = sum(self.carrodecompra)
        self.baixa(proc_produto, quant)
        
        entrar = 'select cod from Venda order by cod desc limit 1'
        self.cursorzinho.execute(entrar)
        lista = self.cursorzinho.fetchall()
        cod_entrada = (lista[0][0])
        comando_sql = f'insert into Venda_Produto (cod_venda, cod_produtos, valor_total) value ({cod_entrada}, {proc_produto}, {total_compra})'
        self.cursorzinho.execute(comando_sql)
        
    def baixa(self, proc_produto, quant):
            comando_sql = f'update Produto set quantidade = quantidade - {quant} where cod = {proc_produto}'
            self.cursorzinho.execute(comando_sql)
            self.conexao.commit()
            print('\nBaixa no sistema confirmada!')
