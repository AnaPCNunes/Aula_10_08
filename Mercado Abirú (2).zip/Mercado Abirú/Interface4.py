from tkinter import *
from tkinter import messagebox
from Class_Cadastro import *
from Class_Compra import *
import posiciona


class Modulo1:
    def __init__(self):
        self.conexao = mysql.connector.connect(host='localhost', user='root', password='q1w2e3', database='mercado')
        self.cursorzinho = self.conexao.cursor()
        
        self.catalogo = Cadastro()
        self.catalogo1 = Compra()
        self.catalogo1.gerenciar = self.catalogo
        
        self.window = Tk()

        self.window.geometry('990x600+200+200')
        self.window.title('Supermercado Abirú')
        self.window.resizable(width=False, height=False)
        
        #===============================================| Função posiciona |======================================================
        self.window.bind('<Button-1>', posiciona.inicio_place)
        self.window.bind('<ButtonRelease-1>', lambda arg: posiciona.fim_place(arg, self.window))
        self.window.bind('<Button-2>', lambda arg: posiciona.para_geometry(self.window))

        #================================================| Imagens Gerais |=======================================================
        self.bVoltar = PhotoImage(file='SistemaAbirú/BotaoVoltar.png')

        self.bCad = PhotoImage(file='SistemaAbirú/BotaoCadastro.png')

        self.bAlt = PhotoImage(file='SistemaAbirú/BotaoAlterar.png')

        self.bExc = PhotoImage(file='SistemaAbirú/BotaoExcluir.png')

        self.bLixo = PhotoImage(file='SistemaAbirú/BotaoLixeira.png')

        self.bVenda = PhotoImage(file='SistemaAbirú/BotaoVenda.png')

        self.bConfig = PhotoImage(file='SistemaAbirú/BotaoConfiguraçao.png')

        self.bSair = PhotoImage(file='SistemaAbirú/BotaoSair.png')

        self.bSalvar = PhotoImage(file='SistemaAbirú/BotaoSalvar.png')

        self.bPesquisa = PhotoImage(file='SistemaAbirú/BotaoPesquisar.png')

        # ========================================| Imagens Primeiro Frame (Login) |==============================================
        self.login = PhotoImage(file='Imagens/Login.png')
        
        self.bLogin = PhotoImage(file='Imagens/botaoLogin.png')

        # =========================================| Imagens Segundo Frame (Menu) |===============================================
        self.menu = PhotoImage(file='SistemaAbirú/1home.png')

        #========================================| Imagens Terceiro Frame (Cadastro) |============================================
        self.cad = PhotoImage(file='SistemaAbirú/2cadastro.png')

        self.bSalvarCad = PhotoImage(file='SistemaAbirú/BotaoSalvarCad.png')

        #=========================================| Imagens Quarto Frame (Alteração) |============================================
        self.alt = PhotoImage(file='SistemaAbirú/3alteração.png')

        self.bSeguir = PhotoImage(file='SistemaAbirú/botaoSeguir.png')

        #===========================================| Imagens Quinto Frame (Excluir) |============================================
        self.excluir = PhotoImage(file='SistemaAbirú/4excluir.png')

        self.bConfir = PhotoImage(file='SistemaAbirú/BotaoConfirmar.png')

        #=============================================| Imagens Sexto Frame (Venda) |=============================================
        self.exc = PhotoImage(file='SistemaAbirú/5Venda.png')

        self.bConfir = PhotoImage(file='SistemaAbirú/botaoConfirmar.png')

        #==================================================| Criação de Frames |==================================================
        self.f1 = Frame(self.window)
        self.f1.pack()
        self.f2 = Frame(self.window)
        self.f3 = Frame(self.window)
        self.f4 = Frame(self.window)
        self.f5 = Frame(self.window)
        self.f6 = Frame(self.window)

        #========================================================| Login |========================================================
        self.lLogin = Label(self.f1, image=self.login)
        self.lLogin.pack()

        self.b1 = Button(self.f1, bd=0, image=self.bLogin, command= lambda: self.tMenu())
        self.b1.place(width=303, height=90, x=580, y=394)

        self.ent1 = Entry(self.f1, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 15')
        self.ent1.place(width=245, height=23, x=607, y=309)

        self.ent1.insert(0, "R.A.")
        self.ent1.configure(state=DISABLED)

        def on_click(event):
            self.ent1.configure(state=NORMAL)
            self.ent1.delete(0, END)

            # make the callback only work once
            self.ent1.unbind('<Button-1>', on_click_id)

        on_click_id = self.ent1.bind('<Button-1>', on_click)

        #========================================================| Home |=========================================================
        self.lMenu = Label(self.f2, image=self.menu)
        self.lMenu.pack()

        self.b3 = Button(self.f2, bd=0, image=self.bVoltar, command=lambda: [self.f2.forget(), self.f1.pack()])
        self.b3.place(width=72, height=65, x=11, y=7)

        self.b2 = Button(self.f2, bd=0, image=self.bCad, command=self.tCadastro)
        self.b2.place(width=79, height=74, x=6, y=83)

        self.b4 = Button(self.f2, bd=0, image=self.bAlt, command=self.tAlterar)
        self.b4.place(width=72, height=78, x=11, y=171)

        self.b5 = Button(self.f2, bd=0, image=self.bExc, command=self.tExcluir)
        self.b5.place(width=65, height=76, x=15, y=257)

        self.bt2 = Button(self.f2, bd=0, image=self.bVenda)
        self.bt2.place(width=82, height=74, x=5, y=344)
        
        self.bt3 = Button(self.f2, bd=0, image=self.bConfig)
        self.bt3.place(width=73, height=72, x=10, y=520)

        self.bt4 = Button(self.f2, bd=0, image=self.bSair)
        self.bt4.place(width=76, height=75, x=904, y=5)

        #===================================================| Cadastro de Produto |==============================================
        self.lCad = Label(self.f3, image=self.cad)
        self.lCad.pack()

        self.b6 = Button(self.f3, bd=0, image=self.bVoltar, command=lambda: [self.f3.forget(), self.f2.pack()])
        self.b6.place(width=72, height=65, x=11, y=7)

        self.ent2 = Entry(self.f3, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 13 bold')
        self.ent2.place(width=239, height=21, x=606, y=257)

        self.ent3 = Entry(self.f3, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 13 bold')
        self.ent3.place(width=239, height=21, x=604, y=347)

        self.ent4 = Entry(self.f3, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 13 bold')
        self.ent4.place(width=239, height=21, x=605, y=442)

        self.b7 = Button(self.f3, bd=0, image=self.bSalvarCad, command= lambda: self.cad_p())
        self.b7.place(width=335, height=65, x=557, y=488)

        #=================================================| Alteração de Produto |================================================
        self.lAlt = Label(self.f4, image=self.alt)
        self.lAlt.pack()

        self.b7 = Button(self.f4, bd=0, image=self.bVoltar, command=lambda: [self.f4.forget(), self.f2.pack()])
        self.b7.place(width=72, height=65, x=11, y=7)

        self.ent5 = Entry(self.f4, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent5.place(width=241, height=25, x=229, y=176)
        
        self.b8 = Button(self.f4, bd=0, image=self.bSalvar)
        self.b8.place(width=215, height=68, x=761, y=493)

        self.bt = Button(self.f4, bd=0, image=self.bPesquisa, command=self.listar)
        self.bt.place(width=48, height=39, x=470, y=170)
        
        self.listbx = Listbox(self.f4, bg='#EBE7D9', fg='#342F4B', bd=0,font='Arial 15')
        self.listbx.place(width=531, height=235, x=187, y=310)

        self.ent9 = Entry(self.f4, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent9.place(width=183, height=25, x=778, y=437)

        self.rbDesc = Radiobutton(self.f4, bd=0, bg='#342F4B', fg='#000', value=1, variable='')
        self.rbDesc.place(width=24, height=26, x=810, y=300)

        self.rbVal = Radiobutton(self.f4, bd=0, bg='#342F4B', fg='#000', value=2, variable='')
        self.rbVal.place(width=24, height=26, x=810, y=336)

        self.bt5 = Button(self.f4, bd=0, image=self.bLixo)
        self.bt5.place(width=47, height=49, x=114, y=509)

        #======================================================| Excluir |====================================================
        self.lExc = Label(self.f5, image=self.excluir)
        self.lExc.pack()

        self.b9 = Button(self.f5, bd=0, image=self.bVoltar, command=lambda: [self.f5.forget(), self.f2.pack()])
        self.b9.place(width=72, height=65, x=11, y=7)

        self.ent6 = Entry(self.f5, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent6.place(width=241, height=25, x=229, y=176)

        self.ent7 = Entry(self.f5, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent7.place(width=261, height=24, x=364, y=361)

        self.b10 = Button(self.f5, bd=0, image=self.bConfir)
        self.b10.place(width=275, height=80, x=395, y=494)

        self.bt6 = Button(self.f5, bd=0, image=self.bPesquisa, command=self.listar)
        self.bt6.place(width=48, height=39, x=470, y=168)

        self.bt7 = Button(self.f5, bd=0, image=self.bLixo)
        self.bt7.place(width=50, height=53, x=916, y=404)

        self.listbx2 = Listbox(self.f5, bg='#EBE7D9', fg='#342F4B', bd=0, font='Arial 15')
        self.listbx2.place(width=754, height=103, x=140, y=340)

        #====================================================| Venda |==================================================
        self.lExc = Label(self.f6, image=self.exc)
        self.lExc.pack()

        self.b11 = Button(self.f6, bd=0, image=self.bVoltar, command=lambda: [self.f6.forget(), self.f2.pack()])
        self.b11.place(width=72, height=65, x=11, y=7)

        self.ent8 = Entry(self.f6, bd=0, bg='#EBE7D9', fg='#342F4B', justify='center', font='Lato 14')
        self.ent8.place(width=263, height=25, x=363, y=164)

        self.b12 = Button(self.f6, bd=0, image=self.bConfir, command=lambda: self.mess())
        self.b12.place(width=275, height=80, x=360, y=494)

        self.bt1 = Button(self.f6, bd=0, image=self.bPesquisa)
        self.bt1.place(width=48, height=34, x=592, y=160)


        self.window.mainloop()

    #================| Funções |=====================
    def tMenu(self):
        self.f1.forget()
        self.f2.pack()

    def tCadastro(self):
        self.f2.forget()
        self.f3.pack()

    def tAlterar(self):
        self.f2.forget()
        self.f4.pack()

    def tExcluir(self):
        self.f2.forget()
        self.f5.pack()

    def tVenda(self):
        self.f2.forget()
        self.f6.pack()
    
    def login_entrar(self):
        self.cursorzinho.execute('select * from Funcionario')
        lista = self.cursorzinho.fetchall()
        for i in range(len(lista)):
            if (lista[i][0]) == self.ent1.get() and (lista[i][2]) == 'Gerente':
                self.tMenu()
            elif (lista[i][0]) != self.ent1.get():
                messagebox.showerror('ERRO!!', 'Seu RA está incorreto. Tente novamente.')
            elif (lista[i][2]) != 'Gerente':
                messagebox.showwarning('Acesso Negado!!', 'Você não tem permição para acessar essas informações.')
                
    def cad_p(self):
        cod = None
        self.catalogo.cadastrar_produtos(cod, self.ent2.get(), self.ent3.get(), self.ent4.get())
        self.ent2.delete(0, END)
        self.ent3.delete(0, END)
        self.ent4.delete(0, END)
    
    def mess(self):
        messagebox.askquestion('Confirmação', 'Tem certeza que quer deletar esse item?')
        if 'Sim':
            self.exc_p()
        else: 
            pass
    
    def exc_p(self):
        p_excluir = self.ent8.get()
        self.catalogo.excluir_cadastro(p_excluir)

    
    def listar(self):
        cad = Cadastro()
        a = self.ent5.get()
        cad = cad.listar_produtos(a)
        
        if a != '':
            self.listbx.insert(END, cad)
        else:
            info = messagebox.showerror('EROU   !', 'Digite algum codigo')

       
'''     
def clear():
    unityinfo.delete(0,END)
       
 '''   
             
janela = Modulo1()