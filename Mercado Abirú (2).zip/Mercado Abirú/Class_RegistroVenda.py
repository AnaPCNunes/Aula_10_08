class RegistroVenda:
    def __init__(self, cod, observacoes):
        self.cod = cod
        self.observacoes = observacoes
