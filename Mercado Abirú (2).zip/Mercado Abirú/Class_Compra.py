from Class_Cadastro import *
from Class_Abastecer import *

class Compra:
    def __init__(self):
        self.conexao = mysql.connector.connect(host='localhost', user='root', password='q1w2e3', database='mercado')
        self.cursorzinho = self.conexao.cursor()
        self.gerenciar = Cadastro()
        
    def compra(self, cod, observacoes, cod_produto, info):
        obj_compra = Abastecer(cod, observacoes)
        comando_sql = f'insert into Abastecer (observacoes) value ("{obj_compra.observacoes}")'
        self.cursorzinho.execute(comando_sql)
        self.conexao.commit()
        try:
            comprar = 'select cod from Abastecer order by cod desc limit 1'
            self.cursorzinho.execute(comprar)
            lista = self.cursorzinho.fetchall()
            cod_abastecer = (lista[0][0])
            comando_sql = f'insert into Abastecer_Produto (cod_abastecer, cod_produto) value ({cod_abastecer}, {cod_produto})'
            self.cursorzinho.execute(comando_sql)
        except:
             print('\nCódigo não encontrado!\n')
        else:
            self.conexao.commit()
            comando_sql = f'update Produto set quantidade = quantidade + {info} where cod = {cod_produto}'
            self.cursorzinho.execute(comando_sql)
            self.conexao.commit()
            print('\nAbastecimento confirmado!')
