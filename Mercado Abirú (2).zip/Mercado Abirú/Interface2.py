from locale import windows_locale
from tkinter import *
import posiciona

class Modulo2:
    def __init__(self):
        self.windowCaixa = Tk()

        self.windowCaixa.geometry('990x600+200+200')
        self.windowCaixa.title('Abirù')
        self.windowCaixa.resizable(width=False, height=False)

        self.windowCaixa.bind('<Button-1>', posiciona.inicio_place)
        self.windowCaixa.bind('<ButtonRelease-1>', lambda arg: posiciona.fim_place(arg, self.windowCaixa))
        self.windowCaixa.bind('<Button-2>', lambda arg: posiciona.para_geometry(self.windowCaixa))

        #==================================| Frame 1 |===================================
        self.telaLogin = PhotoImage(file='Imagens/Login.png')

        self.bLogin = PhotoImage(file='Imagens/botaoLogin.png')

        #==================================| Frame 2 |===================================
        self.telaCaixa = PhotoImage(file='Imagens/Venda2.png')

        #==================================| Criando os Frames |=========================
        self.f1 = Frame(self.windowCaixa)
        self.f1.pack()
        self.f2 = Frame(self.windowCaixa)
        self.f3 = Frame(self.windowCaixa)

        #==================================| Label do Frame 1 |==========================
        self.lab_telaLogin = Label(self.f1, image=self.telaLogin)
        self.lab_telaLogin.pack()

        self.b1 = Button(self.f1, image=self.bLogin, bd=0, command=self.tela2)
        self.b1.place(width=303, height=90, x=580, y=394)

        self.ent1 = Entry(self.f1, bd=0, font='Lato 15', justify='center', bg='#EBE7D9', fg='#342F4B')
        self.ent1.place(width=242, height=29, x=610, y=306)

        self.ent1.insert(0,'R.A')
        self.ent1.configure(state=DISABLED)

        def on_click(event):
            self.ent1.configure(state=NORMAL)
            self.ent1.delete(0, END)

            # make the callback only work once
            self.ent1.unbind('<Button-1>', on_click_id)

        on_click_id = self.ent1.bind('<Button-1>', on_click)

        #==================================| Label do Frame 2 |==========================
        self.lab_telaCaixa = Label(self.f2, image=self.telaCaixa)
        self.lab_telaCaixa.pack()

        self.ent2 = Entry(self.f2, bd=0, font='Lato 17', justify='center', bg='#EBE7D9', fg='#342F4B')
        self.ent2.place(width=290, height=62, x=283, y=102)

        self.ent3 = Entry(self.f2, bd=0, font='Lato 17', justify='center', bg='#EBE7D9', fg='#342F4B')
        self.ent3.place(width=290, height=61, x=637, y=101)


        self.windowCaixa.mainloop()


    def tela2(self):
        self.f1.forget()
        self.f2.pack()


janela = Modulo2()